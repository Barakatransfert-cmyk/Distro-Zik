# DistroZik — prototype

Prototype d'une seule page (`index.html`) pour une plateforme de vente de musique par des artistes subsahariens installés au Maroc : filtre par ville, fiches artistes, simulateur de commission à 15%, aperçu du formulaire d'inscription artiste.

## Héberger sur GitHub Pages (gratuit, en 5 minutes)

1. Crée un dépôt sur GitHub, par exemple `distrozik`.
2. Mets `index.html` (et ce README si tu veux) à la racine du dépôt.
3. Dans le dépôt : **Settings → Pages → Source** → choisis la branche `main` et le dossier `/root`.
4. Après 1–2 minutes, le site est visible à `https://<ton-nom-utilisateur>.github.io/distrozik/`.

C'est tout ce qu'il faut pour que la page soit visible en ligne, gratuitement.

## Ce que ce prototype fait déjà

- Design complet, filtre par ville, fiches artistes, simulateur de commission — tout fonctionne dans le navigateur.

## Ce que GitHub Pages ne peut PAS faire (important)

GitHub Pages n'héberge que des fichiers statiques (HTML/CSS/JS). Il ne peut pas :

- **Stocker des comptes artistes ni des mots de passe** — il faut une base de données (ex. Supabase, Firebase, PostgreSQL sur un serveur).
- **Recevoir et stocker de vrais fichiers audio/photos** uploadés par les artistes — il faut un espace de stockage (ex. Supabase Storage, Cloudflare R2, AWS S3).
- **Traiter de vrais paiements (Airtel Money, Orange Money, carte bancaire, etc.)** — cela demande un serveur backend qui appelle les API de ces opérateurs, avec des clés secrètes qui ne doivent jamais être visibles dans le code du site.
- **Prélever automatiquement une commission** — le partage 85/15 doit être calculé et exécuté côté serveur au moment du paiement, pas dans le navigateur du visiteur.

En clair : ce fichier est la **vitrine**. Pour que les artistes puissent réellement créer un compte, uploader leur musique et être payés, il faut ajouter un **backend** (un petit serveur, par exemple avec Node.js ou Supabase) connecté à de vrais comptes marchands Airtel Money / Orange Money / etc.

## À savoir avant de lancer un vrai service de paiement

Encaisser de l'argent pour le compte de tiers et prélever une commission est une activité encadrée par la réglementation financière (au Maroc et dans les pays d'origine des moyens de paiement utilisés). Avant de traiter de vrais paiements, il est recommandé de te renseigner sur :

- le statut requis pour agir comme intermédiaire de paiement ou marketplace au Maroc,
- les conditions des agrégateurs de paiement qui peuvent gérer Airtel Money / Orange Money / MTN MoMo / cartes pour toi (ex. CMI, PayDunya, Kkiapay, Flutterwave, MaxiCash), qui évitent souvent d'avoir à obtenir un agrément soi-même,
- la fiscalité applicable à la commission perçue.

Je ne suis ni juriste ni conseiller financier — c'est à vérifier auprès d'un professionnel ou des autorités compétentes avant le lancement.
